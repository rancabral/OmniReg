"""Pipeline module initialization"""
